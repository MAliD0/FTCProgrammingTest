public class Main {

    public static void main(String[] args) {
        CreatingMatrix creatingMatrix = new CreatingMatrix(10);
        Sticks sticks = new Sticks();
        System.out.println(creatingMatrix.numOfBox);
        System.out.println("Num of sticks:"+ sticks.Sticks(creatingMatrix.getMatrix(), creatingMatrix.getNumOfBox()));
    }
}